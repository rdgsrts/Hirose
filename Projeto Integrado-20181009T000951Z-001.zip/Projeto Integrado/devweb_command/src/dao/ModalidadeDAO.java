package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.ArrayList;

import dao.ConnectionFactory;
import model.Modalidade;

public class ModalidadeDAO 
{
	public int criar(Modalidade modalidade) 
	{
		String sqlInsert = "INSERT INTO Modalidade(IdModalidade, nome, tipo) VALUES (?, ?, ?)";
		// usando o try with resources do Java 7, que fecha o que abriu
		try (Connection conn = ConnectionFactory.obtemConexao();
				PreparedStatement stm = conn.prepareStatement(sqlInsert);) {
			stm.setInt(1, modalidade.getId());
			stm.setString(2, modalidade.getNome());
			stm.setString(3, modalidade.getTipo());
			stm.execute();
			String sqlQuery = "SELECT LAST_INSERT_ID()";
			try (PreparedStatement stm2 = conn.prepareStatement(sqlQuery);
					ResultSet rs = stm2.executeQuery();) 
			{
				if (rs.next()) 
				{
					modalidade.setId(rs.getInt(1));
				}
			} 
			catch (SQLException e) 
			{
				e.printStackTrace();
			}
		
		} 
		catch (SQLException e) {
			e.printStackTrace();
		}
		
		return modalidade.getId();
	}

	public void atualizar(Modalidade modalidade) {
		String sqlUpdate = "UPDATE Modalidade SET IdModalidade=?, nome=?, tipo=? WHERE idModalidade=?";
		// usando o try with resources do Java 7, que fecha o que abriu
		try (Connection conn = ConnectionFactory.obtemConexao();
				PreparedStatement stm = conn.prepareStatement(sqlUpdate);) {
			stm.setInt(1, modalidade.getId());
			stm.setString(2, modalidade.getNome());
			stm.setString(3, modalidade.getTipo());
			stm.setInt(4, modalidade.getId());
			stm.execute();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void excluir(int id) {
		String sqlDelete = "DELETE FROM Modalidade WHERE idModalidade = ?";
		// usando o try with resources do Java 7, que fecha o que abriu
		try (Connection conn = ConnectionFactory.obtemConexao();
				PreparedStatement stm = conn.prepareStatement(sqlDelete);) {
			stm.setInt(1, id);
			stm.execute();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public ArrayList<Modalidade> carregar() 
	{
		ArrayList<Modalidade> modalidade = new ArrayList<Modalidade>();
		String sqlSelect = "SELECT * FROM Modalidade order by idModalidade";
		// usando o try with resources do Java 7, que fecha o que abriu
		try (Connection conn = ConnectionFactory.obtemConexao();
				PreparedStatement stm = conn.prepareStatement(sqlSelect);) 
		{
			try (ResultSet rs = stm.executeQuery();) 
			{
				while (rs.next()) 
				{
					Modalidade mod = new Modalidade(rs.getInt("IdModalidade"), 
						rs.getString("nome"), rs.getString("tipo"));
					
					modalidade.add(mod);
				}
			} 
			catch (SQLException e) 
			{
				e.printStackTrace();
				System.out.println("Erro ao carregar tabela.");
			}
		} 
		catch (SQLException e1) 
		{
			System.out.print(e1.getStackTrace());
		}
		return modalidade;
	}
}
