package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import dao.ConnectionFactory;
import model.Pais;

public class PaisDAO 
{
	public int criar(Pais pais) 
	{
		String sqlInsert = "INSERT INTO Pais(idPais, nome, populacao, area) VALUES (?, ?, ?, ?)";
		
		try (Connection conn = ConnectionFactory.obtemConexao();
			 PreparedStatement stm = conn.prepareStatement(sqlInsert);) //fecha 
		{
			stm.setInt(1, pais.getId());
			stm.setString(2, pais.getNome());
			stm.setLong(3, pais.getPopulacao());
			stm.setDouble(4, pais.getArea());
			
			stm.execute();
			String sqlQuery = "SELECT LAST_INSERT_ID()";
			
			try (PreparedStatement stm2 = conn.prepareStatement(sqlQuery);
					ResultSet rs = stm2.executeQuery();) 
			{
				if (rs.next()) 
				{
					pais.setId(rs.getInt(1));
				}
			} 
			catch (SQLException e) 
			{
				e.printStackTrace();
			}
		
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		
		return pais.getId();
	}

	public void atualizar(Pais pais) {
		String sqlUpdate = "UPDATE Pais SET idPais=?, nome=?, populacao=?, area=? WHERE idPais=?";
		// usando o try with resources do Java 7, que fecha o que abriu
		try (Connection conn = ConnectionFactory.obtemConexao();
				PreparedStatement stm = conn.prepareStatement(sqlUpdate);) {
			stm.setInt(1, pais.getId());
			stm.setString(2, pais.getNome());
			stm.setLong(3, pais.getPopulacao());
			stm.setDouble(4, pais.getArea());
			stm.execute();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void excluir(int id) {
		String sqlDelete = "DELETE FROM Pais WHERE idPais = ?";
		// usando o try with resources do Java 7, que fecha o que abriu
		try (Connection conn = ConnectionFactory.obtemConexao();
				PreparedStatement stm = conn.prepareStatement(sqlDelete);) {
			stm.setInt(1, id);
			stm.execute();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public Pais carregar(int id) 
	{
		Pais pais = new Pais();
		pais.setId(id);
		
		String sqlSelect = "SELECT idPais, nome, populacao, area FROM Pais WHERE Pais.idPais = ?";
		// usando o try with resources do Java 7, que fecha o que abriu
		
		try (Connection conn = ConnectionFactory.obtemConexao();
				PreparedStatement stm = conn.prepareStatement(sqlSelect);) 
		{
			stm.setInt(1, pais.getId());
			try (ResultSet rs = stm.executeQuery();) 
			{
				while(rs.next()) 
				{
					pais.setId(rs.getInt("idPais"));
					pais.setNome(rs.getString("nome"));
					pais.setPopulacao(rs.getLong("populacao"));
					pais.setArea(rs.getDouble("area"));
				}
			} 
			catch (SQLException e) 
			{
				e.printStackTrace();
			}
		} 
		catch (SQLException e1) 
		{
			System.out.print(e1.getStackTrace());
		}
		return pais;
	}
}
