package service;

import java.util.ArrayList;

import model.Modalidade;
import dao.ModalidadeDAO;

public class ModalidadeService 
{
	ModalidadeDAO dao = new ModalidadeDAO();
	
	public int criar(Modalidade modalidade) 
	{
		return dao.criar(modalidade);
	}
	
	public void atualizar(Modalidade modalidade)
	{
		dao.atualizar(modalidade);
	}
	
	public void excluir(int id)
	{
		dao.excluir(id);
	}
	
	public ArrayList<Modalidade> carregar()
	{
		return dao.carregar();
	}
}
