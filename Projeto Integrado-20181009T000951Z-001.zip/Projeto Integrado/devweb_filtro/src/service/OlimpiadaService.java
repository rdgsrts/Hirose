package service;

import model.Olimpiada;
import dao.OlimpiadaDAO;

public class OlimpiadaService 
{
	/*OlimpiadaDAO dao = new OlimpiadaDAO();
	
	public int criar(Olimpiada olm) 
	{
		return dao.criar(olm);
	}
	
	public void atualizar(Olimpiada olm)
	{
		dao.atualizar(olm);
	}
	
	public void excluir(int id)
	{
		dao.excluir(id);
	}
	
	public Olimpiada carregar(int id)
	{
		return dao.carregar(id);
	}*/
}
