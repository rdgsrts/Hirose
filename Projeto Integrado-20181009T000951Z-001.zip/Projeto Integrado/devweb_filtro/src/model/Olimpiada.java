package model;

//import java.util.ArrayList;

public class Olimpiada
{
	private int ano;
	private String tipo;
	private int ouro, prata, bronze;
	
	public Olimpiada() 
	{
		ano = 0;
		tipo = "";
		ouro = prata = bronze = 0;
		//modalidade = new ArrayList<Modalidade>();
	}

	public Olimpiada(int ano, String tipo, int ouro, int prata, int bronze) 
	{
		this.ano = ano;
		this.tipo = tipo;
		this.ouro = ouro;
		this.prata = prata;
		this.bronze = bronze;
	}

	public int getAno() 
	{
		return ano;
	}

	public void setAno(int ano) {
		this.ano = ano;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}
	
	public int getOuro() {
		return ouro;
	}

	public void setOuro(int ouro) {
		this.ouro = ouro;
	}

	public int getPrata() {
		return prata;
	}

	public void setPrata(int prata) {
		this.prata = prata;
	}

	public int getBronze() {
		return bronze;
	}

	public void setBronze(int bronze) {
		this.bronze = bronze;
	}

	@Override
	public String toString() {
		return "Olimpiada [ano=" + ano + ", tipo=" + tipo + ", getAno()=" + getAno() + ", getTipo()=" + getTipo() + "]";
	}
	
}
