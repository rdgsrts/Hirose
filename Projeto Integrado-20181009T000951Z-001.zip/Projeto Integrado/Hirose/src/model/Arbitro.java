package model;

public class Arbitro 
{
	private int codTemporada, dataNascimento;
	private String nomeArbitro;
	
	public int getCodTemporada() {
		return codTemporada;
	}
	public void setCodTemporada(int codTemporada) {
		this.codTemporada = codTemporada;
	}
	public int getDataNascimento() {
		return dataNascimento;
	}
	public void setDataNascimento(int dataNascimento) {
		this.dataNascimento = dataNascimento;
	}
	public String getNomeArbitro() {
		return nomeArbitro;
	}
	public void setNomeArbitro(String nomeArbitro) {
		this.nomeArbitro = nomeArbitro;
	}
	
	
}
