create database futebol;
use futebol;

create table Arbitro
(
	id_arbitro auto_increment
	-- id_temp
	nome,
	data_nasc,

	primary key(id_arbitro)
);

create table Campeonato
(
	
);
